
from tccu_agi_suprema.nucleo import TCCUNucleo

if __name__ == "__main__":
    nucleo = TCCUNucleo()
    print("Ecuación de Creación Continua:")
    print(nucleo.campo_creacion())

    print("\nSimulando estabilidad de la garganta...")
    solucion = nucleo.estabilidad_garganta(lambda r: np.exp(-r))
    nucleo.visualizar_campo(solucion)

    coherencia = nucleo.simular_entrelazamiento()
    print(f"\nCoherencia Cuántica Observada: {coherencia:.2%}")

    print("\nGuardando estado de simulación...")
    nucleo.guardar_estado(str(nucleo.campo_creacion()), "creacion_continua")
